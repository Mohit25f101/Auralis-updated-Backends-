# ============================================
# app/services/emotion_detector.py - Micro-Emotion Detection
# ============================================

import re
from typing import Dict, Any, List, Optional, Tuple
from collections import defaultdict

import numpy as np

from config import settings, EMOTIONS, SITUATIONS
# NEW (Fixed)
from core.logger import get_logger

logger = get_logger()

# Optional imports
try:
    import librosa
    LIBROSA_AVAILABLE = True
except ImportError:
    LIBROSA_AVAILABLE = False


class EmotionDetector:
    """
    Advanced micro-emotion detection system.
    Detects subtle emotional states like urgency, excitement, and hesitation.
    Includes Asian geographical context awareness.
    """
    
    # Asian language emotional markers
    ASIAN_EMOTIONAL_MARKERS = {
        "urgency": {
            "hindi": ["jaldi", "abhi", "turant", "fatafat", "jhat se"],
            "japanese": ["hayaku", "isoide", "sugu ni"],
            "korean": ["ppalli", "jigeum"],
            "chinese": ["kuai", "mashang"],
            "thai": ["reo reo", "diaw ni"],
            "malay": ["cepat", "segera"]
        },
        "excitement": {
            "hindi": ["wah", "bahut", "zabardast", "mast"],
            "japanese": ["sugoi", "yatta", "kawaii"],
            "korean": ["daebak", "jinjja"],
            "chinese": ["tai bang le", "hao"],
            "thai": ["suay", "dee mak"],
            "malay": ["hebat", "best"]
        },
        "hesitation": {
            "hindi": ["shayad", "lagta hai", "pata nahi", "dekho"],
            "japanese": ["tabun", "chotto", "ano", "eto"],
            "korean": ["geulsse", "mollayo"],
            "chinese": ["keneng", "haoxiang"],
            "thai": ["baang thi", "mai nae jai"],
            "malay": ["mungkin", "entahlah"]
        },
        "politeness": {
            "hindi": ["kripya", "dhanyavad", "shukriya"],
            "japanese": ["onegaishimasu", "sumimasen", "gomen"],
            "korean": ["juseyo", "gamsahamnida"],
            "chinese": ["qing", "xie xie"],
            "thai": ["krap", "ka", "khob khun"],
            "malay": ["tolong", "terima kasih"]
        }
    }
    
    # Filler words for hesitation detection
    FILLER_WORDS = [
        "um", "uh", "er", "ah", "like", "you know", "basically",
        "sort of", "kind of", "well", "so", "actually", "literally",
        "I mean", "right", "okay so"
    ]
    
    def __init__(self):
        self.emotions_config = EMOTIONS
        self.baseline_features: Optional[Dict[str, float]] = None
    
    def analyze(
        self,
        audio: np.ndarray,
        sample_rate: int,
        transcription: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Perform comprehensive emotion analysis.
        
        Args:
            audio: Audio array
            sample_rate: Audio sample rate
            transcription: Transcription results
            
        Returns:
            Complete emotion analysis results
        """
        # Extract audio features
        audio_features = self._extract_audio_features(audio, sample_rate)
        
        # Analyze text for emotional markers
        text = transcription.get("text", "")
        text_emotions = self._analyze_text_emotions(text)
        
        # Detect Asian context markers
        asian_context = self._detect_asian_context(text)
        
        # Analyze prosodic features
        prosodic_emotions = self._analyze_prosodic_features(audio_features)
        
        # Detect hesitation
        hesitation_analysis = self._analyze_hesitation(text, audio_features)
        
        # Combine all emotion scores
        combined_emotions = self._combine_emotion_scores(
            text_emotions, prosodic_emotions, asian_context
        )
        
        # Calculate emotional intensity and stability
        intensity = self._calculate_intensity(audio_features, combined_emotions)
        stability = self._calculate_stability(audio_features)
        
        # Get primary emotion
        primary_emotion, primary_score = self._get_primary_emotion(combined_emotions)
        
        # Build detailed emotion scores
        emotion_scores = []
        for emotion, score in combined_emotions.items():
            if score > 0.1:
                emotion_scores.append({
                    "emotion": emotion,
                    "score": round(score, 4),
                    "confidence": round(min(score * 1.2, 0.98), 4),
                    "indicators": self._get_emotion_indicators(emotion, text, audio_features)
                })
        
        emotion_scores.sort(key=lambda x: x["score"], reverse=True)
        
        return {
            "primary_emotion": primary_emotion,
            "primary_score": round(primary_score, 4),
            "all_emotions": emotion_scores[:8],
            "emotional_intensity": round(intensity, 4),
            "emotional_stability": round(stability, 4),
            "asian_context_detected": asian_context.get("detected", False),
            "context_emotions": asian_context.get("emotions", []),
            "hesitation_analysis": hesitation_analysis,
            "audio_features_used": {
                "pitch_variance": audio_features.get("pitch_variance", 0),
                "speech_rate": audio_features.get("speech_rate", 1.0),
                "energy_variance": audio_features.get("energy_variance", 0)
            }
        }
    
    def _extract_audio_features(
        self,
        audio: np.ndarray,
        sample_rate: int
    ) -> Dict[str, float]:
        """Extract audio features for emotion analysis."""
        features = {
            "duration": len(audio) / sample_rate,
            "energy_mean": float(np.mean(audio ** 2)),
            "energy_std": float(np.std(audio ** 2)),
            "energy_variance": 0.0,
            "zero_crossings": int(np.sum(np.abs(np.diff(np.signbit(audio))))),
            "pitch_mean": 0.0,
            "pitch_std": 0.0,
            "pitch_variance": 0.0,
            "speech_rate": 1.0,
            "spectral_centroid": 0.0,
            "spectral_bandwidth": 0.0
        }
        
        if not LIBROSA_AVAILABLE:
            return features
        
        try:
            # RMS energy
            rms = librosa.feature.rms(y=audio)[0]
            features["energy_mean"] = float(np.mean(rms))
            features["energy_std"] = float(np.std(rms))
            features["energy_variance"] = features["energy_std"] / (features["energy_mean"] + 1e-6)
            
            # Pitch estimation
            pitches, magnitudes = librosa.piptrack(y=audio, sr=sample_rate)
            pitch_values = []
            for t in range(pitches.shape[1]):
                index = magnitudes[:, t].argmax()
                pitch = pitches[index, t]
                if pitch > 0:
                    pitch_values.append(pitch)
            
            if pitch_values:
                features["pitch_mean"] = float(np.mean(pitch_values))
                features["pitch_std"] = float(np.std(pitch_values))
                features["pitch_variance"] = features["pitch_std"] / (features["pitch_mean"] + 1e-6)
            
            # Spectral features
            spectral_centroids = librosa.feature.spectral_centroid(y=audio, sr=sample_rate)[0]
            features["spectral_centroid"] = float(np.mean(spectral_centroids))
            
            spectral_bandwidth = librosa.feature.spectral_bandwidth(y=audio, sr=sample_rate)[0]
            features["spectral_bandwidth"] = float(np.mean(spectral_bandwidth))
            
            # Speech rate estimation (based on onset detection)
            onset_frames = librosa.onset.onset_detect(y=audio, sr=sample_rate)
            duration = len(audio) / sample_rate
            if duration > 0:
                features["speech_rate"] = len(onset_frames) / duration * 0.4  # Approximate syllables
        
        except Exception as e:
            logger.debug(f"Audio feature extraction error: {e}")
        
        return features
    
    def _analyze_text_emotions(self, text):
        """Analyze emotions in text using keyword matching (Robust Fix)"""
        detected_emotions = {}
        text_lower = text.lower()
        
        # 🔧 FIX: Handle both List and Dictionary configs
        if isinstance(self.emotions_config, list):
            # Convert list to dict format for easier processing
            # Assuming list structure: [{"name": "happy", "keywords": [...]}, ...]
            iterator = []
            for item in self.emotions_config:
                if isinstance(item, dict) and "name" in item:
                    iterator.append((item["name"], item))
        else:
            # Standard dictionary iteration
            iterator = self.emotions_config.items()

        for emotion_name, emotion_config in iterator:
            score = 0
            keywords = emotion_config.get("keywords", [])
            
            for word in text_lower.split():
                if word in keywords:
                    score += 1
            
            if score > 0:
                detected_emotions[emotion_name] = min(score * 0.2, 1.0)
                
        return detected_emotions
    
    def _detect_asian_context(self, text: str) -> Dict[str, Any]:
        """Detect Asian language emotional markers."""
        if not text:
            return {"detected": False, "emotions": [], "languages": []}
        
        lower_text = text.lower()
        detected_emotions = []
        detected_languages = set()
        
        for emotion, language_markers in self.ASIAN_EMOTIONAL_MARKERS.items():
            for language, markers in language_markers.items():
                for marker in markers:
                    if marker.lower() in lower_text:
                        detected_emotions.append(emotion)
                        detected_languages.add(language)
        
        return {
            "detected": len(detected_emotions) > 0,
            "emotions": list(set(detected_emotions)),
            "languages": list(detected_languages)
        }
    
    def _analyze_prosodic_features(
        self,
        audio_features: Dict[str, float]
    ) -> Dict[str, float]:
        """Analyze prosodic features for emotion detection."""
        emotions = defaultdict(float)
        
        pitch_variance = audio_features.get("pitch_variance", 0)
        energy_variance = audio_features.get("energy_variance", 0)
        speech_rate = audio_features.get("speech_rate", 1.0)
        
        for emotion_name, emotion_config in self.emotions_config.items():
            indicators = emotion_config.get("indicators", {})
            score = 0.0
            matches = 0
            
            # Check speech rate
            if "speech_rate" in indicators:
                sr_range = indicators["speech_rate"]
                if sr_range["min"] <= speech_rate <= sr_range["max"]:
                    score += 0.3
                    matches += 1
            
            # Check pitch variance
            if "pitch_variance" in indicators:
                pv_range = indicators["pitch_variance"]
                if pv_range["min"] <= pitch_variance <= pv_range["max"]:
                    score += 0.3
                    matches += 1
            
            # Check volume/energy
            if "volume" in indicators:
                vol_range = indicators["volume"]
                if vol_range["min"] <= energy_variance <= vol_range["max"]:
                    score += 0.2
                    matches += 1
            
            if matches > 0:
                emotions[emotion_name] = score
        
        return dict(emotions)
    
    def _analyze_hesitation(
        self,
        text: str,
        audio_features: Dict[str, float]
    ) -> Dict[str, Any]:
        """Analyze hesitation patterns."""
        filler_count = 0
        found_fillers = []
        
        if text:
            lower_text = text.lower()
            for filler in self.FILLER_WORDS:
                count = lower_text.count(filler.lower())
                if count > 0:
                    filler_count += count
                    found_fillers.append(filler)
        
        word_count = len(text.split()) if text else 0
        filler_ratio = filler_count / (word_count + 1)
        
        # Slow speech rate indicates hesitation
        speech_rate = audio_features.get("speech_rate", 1.0)
        slow_speech = speech_rate < 0.8
        
        hesitation_score = min(filler_ratio * 3 + (0.3 if slow_speech else 0), 0.95)
        
        return {
            "hesitation_score": round(hesitation_score, 4),
            "filler_count": filler_count,
            "filler_ratio": round(filler_ratio, 4),
            "fillers_found": found_fillers[:5],
            "slow_speech_detected": slow_speech,
            "is_hesitant": hesitation_score > 0.3
        }
    
    def _combine_emotion_scores(
        self,
        text_emotions: Dict[str, float],
        prosodic_emotions: Dict[str, float],
        asian_context: Dict[str, Any]
    ) -> Dict[str, float]:
        """Combine emotion scores from different sources."""
        combined = defaultdict(float)
        
        # Weight factors
        text_weight = 0.5
        prosodic_weight = 0.4
        context_weight = 0.3
        
        # Add text emotions
        for emotion, score in text_emotions.items():
            combined[emotion] += score * text_weight
        
        # Add prosodic emotions
        for emotion, score in prosodic_emotions.items():
            combined[emotion] += score * prosodic_weight
        
        # Boost Asian context emotions
        if asian_context.get("detected"):
            for emotion in asian_context.get("emotions", []):
                combined[emotion] += context_weight
        
        # Normalize
        max_score = max(combined.values()) if combined else 1.0
        if max_score > 1.0:
            combined = {k: v / max_score for k, v in combined.items()}
        
        return dict(combined)
    
    def _calculate_intensity(
        self,
        audio_features: Dict[str, float],
        emotions: Dict[str, float]
    ) -> float:
        """Calculate overall emotional intensity."""
        # Base intensity from audio energy
        energy_factor = min(audio_features.get("energy_variance", 0) * 2, 0.5)
        
        # Intensity from emotion scores
        if emotions:
            emotion_factor = np.mean(list(emotions.values())) * 0.5
        else:
            emotion_factor = 0.0
        
        # Combine
        intensity = energy_factor + emotion_factor
        return min(intensity, 1.0)
    
    def _calculate_stability(self, audio_features: Dict[str, float]) -> float:
        """Calculate emotional stability (consistency)."""
        # Lower variance = higher stability
        pitch_variance = audio_features.get("pitch_variance", 0)
        energy_variance = audio_features.get("energy_variance", 0)
        
        stability = 1.0 - min((pitch_variance + energy_variance) / 2, 0.8)
        return max(stability, 0.2)
    
    def _get_primary_emotion(
        self,
        emotions: Dict[str, float]
    ) -> Tuple[str, float]:
        """Get the primary detected emotion."""
        if not emotions:
            return "neutral", 0.5
        
        primary = max(emotions.items(), key=lambda x: x[1])
        return primary[0], primary[1]
    
    def _get_emotion_indicators(
        self,
        emotion: str,
        text: str,
        audio_features: Dict[str, float]
    ) -> Dict[str, Any]:
        """Get specific indicators for an emotion."""
        indicators = {}
        
        emotion_config = self.emotions_config.get(emotion, {})
        keywords = emotion_config.get("keywords", [])
        
        # Find matched keywords
        if text:
            lower_text = text.lower()
            matched = [k for k in keywords if k.lower() in lower_text]
            if matched:
                indicators["keywords_matched"] = matched[:3]
        
        # Add relevant audio features
        config_indicators = emotion_config.get("indicators", {})
        
        if "speech_rate" in config_indicators:
            indicators["speech_rate"] = audio_features.get("speech_rate", 1.0)
        
        if "pitch_variance" in config_indicators:
            indicators["pitch_variance"] = audio_features.get("pitch_variance", 0)
        
        return indicators