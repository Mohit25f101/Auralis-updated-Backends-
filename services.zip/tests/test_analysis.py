# ==============================
# 📄 tests/test_analysis.py
# ==============================
"""
Tests for Core Analysis Functionality
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class TestAudioLoader:
    """Tests for AudioLoader service"""
    
    def test_audio_loader_initialization(self):
        """Test AudioLoader initializes correctly"""
        from services.audio_loader import AudioLoader
        
        loader = AudioLoader(sample_rate=16000)
        assert loader.sample_rate == 16000
        assert loader.loaded == True
    
    def test_normalize_audio(self):
        """Test audio normalization"""
        from services.audio_loader import AudioLoader
        
        loader = AudioLoader()
        
        # Create test audio with DC offset
        audio = np.array([0.5, 0.6, 0.7, 0.8, 0.9], dtype=np.float32)
        
        normalized = loader._normalize(audio)
        
        # Check DC offset removed (mean should be ~0)
        assert abs(np.mean(normalized)) < 0.01
        
        # Check normalized to [-1, 1]
        assert np.max(np.abs(normalized)) <= 1.0
    
    def test_supported_formats(self):
        """Test supported format list"""
        from services.audio_loader import AudioLoader
        
        loader = AudioLoader()
        
        assert '.wav' in loader.SUPPORTED_FORMATS
        assert '.mp3' in loader.SUPPORTED_FORMATS
        assert '.m4a' in loader.SUPPORTED_FORMATS
        assert '.flac' in loader.SUPPORTED_FORMATS


class TestLocationDetector:
    """Tests for LocationDetector service"""
    
    def test_location_detector_initialization(self):
        """Test LocationDetector initializes correctly"""
        from services.location_detector import LocationDetector
        
        detector = LocationDetector()
        detector.load()
        
        assert detector.loaded == True
    
    def test_talking_about_detection(self):
        """Test detection of 'talking about' vs 'being at'"""
        from services.location_detector import LocationDetector
        
        detector = LocationDetector()
        detector.load()
        
        # Test "talking about" case
        text_about = "I went to the airport yesterday and it was so crowded"
        result = detector._analyze_speech_context(text_about)
        
        assert result[1] == True  # is_talking_about should be True
    
    def test_being_at_detection(self):
        """Test detection of actually being at location"""
        from services.location_detector import LocationDetector
        
        detector = LocationDetector()
        detector.load()
        
        # Test "being at" case
        text_at = "Attention please, the train is now arriving at platform 3"
        result = detector._analyze_speech_context(text_at)
        
        assert result[1] == False  # is_talking_about should be False
    
    def test_ambient_sound_analysis(self):
        """Test ambient sound scoring"""
        from services.location_detector import LocationDetector
        
        detector = LocationDetector()
        detector.load()
        
        # Test with train sounds
        sounds = {
            "Train": 0.8,
            "Speech": 0.6,
            "Crowd": 0.4
        }
        
        scores = detector._analyze_ambient_sounds(sounds)
        
        assert "Railway Station" in scores
        assert scores["Railway Station"] > 0


class TestSituationClassifier:
    """Tests for SituationClassifier service"""
    
    def test_situation_classifier_initialization(self):
        """Test SituationClassifier initializes correctly"""
        from services.situation_classifier import SituationClassifier
        
        classifier = SituationClassifier()
        classifier.load()
        
        assert classifier.loaded == True
    
    def test_emergency_detection(self):
        """Test emergency situation detection"""
        from services.situation_classifier import SituationClassifier
        
        classifier = SituationClassifier()
        classifier.load()
        
        text = "Emergency! Fire in the building! Everyone evacuate immediately!"
        sounds = {"Alarm": 0.9, "Screaming": 0.7}
        
        result = classifier.classify(text, sounds)
        
        assert result["situation"] == "Emergency"
        assert result["is_emergency"] == True
        assert result["urgency_level"] == "critical"
    
    def test_boarding_detection(self):
        """Test boarding situation detection"""
        from services.situation_classifier import SituationClassifier
        
        classifier = SituationClassifier()
        classifier.load()
        
        text = "Now boarding flight AI302 at gate 15"
        sounds = {"Speech": 0.8, "Aircraft": 0.5}
        
        result = classifier.classify(text, sounds)
        
        assert result["situation"] == "Boarding/Departure"


class TestAnalyzer:
    """Tests for main Analyzer service"""
    
    def test_analyzer_initialization(self):
        """Test Analyzer initializes correctly"""
        from services.analyzer import Analyzer
        from services.learning_system import LearningSystem
        
        learning = LearningSystem()
        analyzer = Analyzer(learning_system=learning)
        
        assert analyzer.loaded == True
    
    def test_analyze_basic(self):
        """Test basic analysis"""
        from services.analyzer import Analyzer
        from services.learning_system import LearningSystem
        
        learning = LearningSystem()
        analyzer = Analyzer(learning_system=learning)
        
        transcription = {
            "text": "Train number 12345 is arriving at platform 3",
            "is_reliable": True,
            "confidence": 0.9
        }
        
        sounds = {
            "sounds": {"Train": 0.8, "Speech": 0.7},
            "location_hints": [("Railway Station", 0.8)],
            "situation_hints": [("Boarding/Departure", 0.7)]
        }
        
        result = analyzer.analyze(transcription, sounds)
        
        assert "location" in result
        assert "situation" in result
        assert "is_emergency" in result
        assert result["text_reliable"] == True


class TestEmotionDetector:
    """Tests for EmotionDetector service"""
    
    def test_emotion_detector_initialization(self):
        """Test EmotionDetector initializes correctly"""
        from services.emotion_detector import EmotionDetector
        
        detector = EmotionDetector()
        detector.load()
        
        assert detector.loaded == True
    
    def test_urgency_detection(self):
        """Test urgency micro-emotion detection"""
        from services.emotion_detector import EmotionDetector
        
        detector = EmotionDetector()
        detector.load()
        
        audio = np.random.randn(16000).astype(np.float32) * 0.1  # 1 second of audio
        text = "Immediately proceed to the emergency exit now!"
        sounds = {"Alarm": 0.8}
        
        result = detector.analyze(audio, text, sounds)
        
        assert "micro_emotions" in result
        assert result["micro_emotions"]["urgency"] > 0.5


class TestConfidenceScorer:
    """Tests for ConfidenceScorer service"""
    
    def test_confidence_scorer_initialization(self):
        """Test ConfidenceScorer initializes correctly"""
        from services.confidence_scorer import ConfidenceScorer
        
        scorer = ConfidenceScorer()
        scorer.load()
        
        assert scorer.loaded == True
    
    def test_high_confidence_speech(self):
        """Test scoring of confident speech"""
        from services.confidence_scorer import ConfidenceScorer
        
        scorer = ConfidenceScorer()
        scorer.load()
        
        audio = np.random.randn(16000).astype(np.float32) * 0.1
        text = "The train will definitely arrive at platform 3 at 10:30 AM."
        
        result = scorer.score(audio, text, 0.9, None)
        
        assert result["overall_score"] >= 6
        assert "definitely" in str(result.get("certainty_indicators", []))
    
    def test_low_confidence_speech(self):
        """Test scoring of uncertain speech"""
        from services.confidence_scorer import ConfidenceScorer
        
        scorer = ConfidenceScorer()
        scorer.load()
        
        audio = np.random.randn(16000).astype(np.float32) * 0.1
        text = "Um, I think maybe the train might arrive, possibly, I'm not sure."
        
        result = scorer.score(audio, text, 0.7, None)
        
        assert result["overall_score"] <= 5


# ==============================
# RUN TESTS
# ==============================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])