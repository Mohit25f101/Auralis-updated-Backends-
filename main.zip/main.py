# ==============================
# main.py - AURALIS ULTIMATE ENHANCED v6.0
# ==============================
"""
Auralis Ultimate - Enhanced Production Audio Analysis API
Main Application Entry Point

ENHANCED FEATURES:
- 150+ Language Support with Auto-Translation to English
- Advanced Speaker Diarization (Multiple Speakers)
- Enhanced Audio Quality Handling (Noise Reduction, VAD)
- Smart Location Detection (Ambient-Based)
- 24 Location Types & 20 Situation Types
- Micro-Emotion Detection
- Speaker Confidence Scoring
- 521 Sound Classes Detection
- Adaptive Learning System
- 10-Minute Audio Support
- Multi-Engine Translation
- Poor Audio Quality Enhancement
"""

import pymysql
pymysql.install_as_MySQLdb()
import MySQLdb
import os
import sys
import logging
import warnings

# Silence warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
os.environ['TRANSFORMERS_VERBOSITY'] = 'error'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
warnings.filterwarnings('ignore')
logging.getLogger('tensorflow').setLevel(logging.ERROR)
logging.getLogger('transformers').setLevel(logging.ERROR)

from contextlib import asynccontextmanager
from datetime import datetime
import shutil

from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List
import numpy as np

# Internal imports
from config import settings, get_learning_file_path, SUPPORTED_LANGUAGES
from services.audio_preprocessor import AudioPreprocessor, preprocess_audio_file
from services.whisper_manager import WhisperManager
from services.speaker_diarizer import SpeakerDiarizer, diarize_audio
from services.multi_engine_translator import MultiEngineTranslator
from services.yamnet_manager import YAMNetManager
from services.emotion_detector import EmotionDetector
from services.confidence_scorer import ConfidenceScorer
from services.context_synthesizer import ContextSynthesizer
from services.location_detector import LocationDetector
from services.ambient_analyzer import AmbientAnalyzer
from services.learning_system import LearningSystem
from services.audio_loader import AudioLoader

# Global service instances
audio_loader = None
whisper_manager = None
yamnet_manager = None
emotion_detector = None
confidence_scorer = None
context_synthesizer = None
location_detector = None
ambient_analyzer = None
learning_system = None
audio_preprocessor = None
speaker_diarizer = None
translator = None


def setup_ffmpeg() -> bool:
    FFMPEG_BIN_DIR = r"D:\photo\ffmpeg\ffmpeg-2026-01-07-git-af6a1dd0b2-full_build\bin"
    try:
        if shutil.which("ffmpeg"):
            print("✅ FFmpeg found in PATH")
            return True
        
        if os.path.isdir(settings.FFMPEG_PATH):
            os.environ["PATH"] = settings.FFMPEG_PATH + os.pathsep + os.environ.get("PATH", "")
            if shutil.which("ffmpeg"):
                print("✅ FFmpeg enabled from configured path")
                return True
        
        print("⚠️ FFmpeg not found - some audio formats may not work")
        return False
        
    except Exception as e:
        print(f"⚠️ FFmpeg setup error: {e}")
        return False


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    
    global audio_loader, whisper_manager, yamnet_manager, emotion_detector
    global confidence_scorer, context_synthesizer, location_detector
    global ambient_analyzer, learning_system, audio_preprocessor
    global speaker_diarizer, translator
    
    print("\n" + "=" * 80)
    print("🚀 AURALIS ULTIMATE ENHANCED v6.0 - Starting...")
    print("=" * 80)
    
    # Setup FFmpeg
    setup_ffmpeg()
    
    try:
        # Initialize core services
        print("\n📦 Initializing Core Services...")
        audio_loader = AudioLoader()
        audio_preprocessor = AudioPreprocessor()
        print("✅ Audio Loader & Preprocessor initialized")
        
        # Initialize Whisper (ASR)
        print("\n🎤 Initializing Speech Recognition...")
        whisper_manager = WhisperManager()
        print("✅ Whisper Manager initialized")
        
        # Initialize Speaker Diarization
        if settings.ENABLE_DIARIZATION:
            print("\n👥 Initializing Speaker Diarization...")
            speaker_diarizer = SpeakerDiarizer()
            print("✅ Speaker Diarizer initialized")
        
        # Initialize Translation
        print("\n🌍 Initializing Translation Services...")
        translator = MultiEngineTranslator()
        print("✅ Multi-Engine Translator initialized")
        
        # Initialize YAMNet (Sound Classification)
        print("\n🔊 Initializing Sound Classification...")
        yamnet_manager = YAMNetManager()
        print("✅ YAMNet Manager initialized")
        
        # Initialize Analysis Services
        print("\n🧠 Initializing Analysis Services...")
        emotion_detector = EmotionDetector()
        confidence_scorer = ConfidenceScorer()
        context_synthesizer = ContextSynthesizer()
        location_detector = LocationDetector()
        ambient_analyzer = AmbientAnalyzer()
        learning_system = LearningSystem(get_learning_file_path())
        print("✅ Analysis Services initialized")
        
        print("\n" + "=" * 80)
        print("✅ AURALIS ULTIMATE ENHANCED v6.0 - Ready!")
        print(f"📡 Server: http://{settings.HOST}:{settings.PORT}")
        print(f"📚 API Docs: http://{settings.HOST}:{settings.PORT}/docs")
        print(f"🌍 Languages Supported: {len(SUPPORTED_LANGUAGES)}")
        print(f"👥 Speaker Diarization: {'Enabled' if settings.ENABLE_DIARIZATION else 'Disabled'}")
        print(f"🎯 Audio Enhancement: {'Enabled' if settings.ENABLE_NOISE_REDUCTION else 'Disabled'}")
        print("=" * 80 + "\n")
        
        yield
        
    except Exception as e:
        print(f"\n❌ Initialization failed: {e}")
        raise
    finally:
        print("\n👋 Shutting down Auralis...")


# Create FastAPI app
app = FastAPI(
    title="Auralis Ultimate Enhanced API",
    description="Advanced Audio Analysis with Multilingual Support & Speaker Diarization",
    version="6.0",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request/Response Models
class AnalysisResponse(BaseModel):
    """Analysis response model"""
    success: bool
    text: str
    language: str
    translated_text: Optional[str] = None
    speakers: Optional[List[dict]] = None
    speaker_count: int = 0
    emotions: dict
    confidence: float
    location: str
    situation: str
    ambient_sounds: List[str]
    suggestions: List[str]
    audio_quality: dict


@app.get("/")
async def root():
    """Root endpoint - redirect to docs"""
    return JSONResponse({
        "message": "Auralis Ultimate Enhanced API v6.0",
        "docs": "/docs",
        "health": "/health",
        "features": {
            "languages": len(SUPPORTED_LANGUAGES),
            "speaker_diarization": settings.ENABLE_DIARIZATION,
            "audio_enhancement": settings.ENABLE_NOISE_REDUCTION,
            "max_duration": settings.MAX_DURATION,
            "max_speakers": settings.MAX_SPEAKERS
        }
    })


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return JSONResponse({
        "status": "healthy",
        "version": "6.0",
        "services": {
            "whisper": whisper_manager is not None,
            "diarization": speaker_diarizer is not None,
            "translation": translator is not None,
            "yamnet": yamnet_manager is not None,
            "audio_processor": audio_preprocessor is not None
        },
        "config": {
            "languages_supported": len(SUPPORTED_LANGUAGES),
            "max_duration": settings.MAX_DURATION,
            "enable_diarization": settings.ENABLE_DIARIZATION,
            "enable_noise_reduction": settings.ENABLE_NOISE_REDUCTION
        }
    })


@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_audio(
    file: UploadFile = File(...),
    language: Optional[str] = Form(None),
    enable_diarization: Optional[bool] = Form(True),
    enable_translation: Optional[bool] = Form(True),
    enhance_audio: Optional[bool] = Form(True)
):
    """
    Analyze audio file with enhanced features
    
    Args:
        file: Audio file to analyze
        language: Source language (auto-detect if None)
        enable_diarization: Whether to perform speaker diarization
        enable_translation: Whether to translate to English
        enhance_audio: Whether to enhance audio quality
    
    Returns:
        Comprehensive analysis results
    """
    
    try:
        # Save uploaded file
        temp_path = f"/tmp/{file.filename}"
        with open(temp_path, "wb") as f:
            f.write(await file.read())
        
        # Load and preprocess audio
        audio, sr = audio_loader.load(temp_path)
        
        # Enhance audio quality if requested
        if enhance_audio and audio_preprocessor:
            audio, sr = audio_preprocessor.enhance_for_speech(audio, sr)
        
        # Assess audio quality
        audio_quality = {
            "duration": len(audio) / sr,
            "sample_rate": sr,
            "enhanced": enhance_audio
        }
        
        # Speaker diarization
        speakers_info = []
        speaker_count = 1
        
        if enable_diarization and speaker_diarizer and settings.ENABLE_DIARIZATION:
            segments, stats = diarize_audio(audio, sr)
            speaker_count = len(stats)
            
            speakers_info = [
                {
                    "speaker_id": seg.speaker_id,
                    "start_time": seg.start_time,
                    "end_time": seg.end_time,
                    "duration": seg.duration
                }
                for seg in segments
            ]
        
        # Transcription
        transcription = whisper_manager.transcribe(
            audio,
            language=language,
            enhance_audio=False,  # Already enhanced
            translate_to_english=enable_translation
        )
        
        text = transcription.get("text", "")
        detected_lang = transcription.get("language", "unknown")
        translated_text = transcription.get("original_text") if enable_translation else None
        
        # Emotion detection
        emotions = emotion_detector.detect(audio, sr) if emotion_detector else {}
        
        # Confidence scoring
        confidence = confidence_scorer.score(text, audio, sr) if confidence_scorer else 0.0
        
        # Ambient sound analysis
        ambient_results = yamnet_manager.classify(audio, sr) if yamnet_manager else []
        ambient_sounds = [r["label"] for r in ambient_results[:5]]
        
        # Location detection
        location = location_detector.detect(ambient_sounds, text) if location_detector else "Unknown"
        
        # Situation classification
        situation = "Normal/Quiet"  # Simplified for this example
        
        # Generate suggestions
        suggestions = []
        if confidence < 0.5:
            suggestions.append("Audio quality could be improved - try recording in a quieter environment")
        if speaker_count > 1:
            suggestions.append(f"Detected {speaker_count} speakers in the audio")
        
        # Clean up
        os.remove(temp_path)
        
        return AnalysisResponse(
            success=True,
            text=text,
            language=detected_lang,
            translated_text=translated_text,
            speakers=speakers_info,
            speaker_count=speaker_count,
            emotions=emotions,
            confidence=confidence,
            location=location,
            situation=situation,
            ambient_sounds=ambient_sounds,
            suggestions=suggestions,
            audio_quality=audio_quality
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/languages")
async def get_languages():
    """Get list of supported languages"""
    return JSONResponse({
        "count": len(SUPPORTED_LANGUAGES),
        "languages": SUPPORTED_LANGUAGES
    })


if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        app,
        host=settings.HOST,
        port=settings.PORT,
        log_level="info"
    )