# ==============================
# config.py - ENHANCED VERSION
# ==============================
"""
Auralis Ultimate Configuration - Enhanced
Central configuration with multilingual support and advanced features
"""

import os
from typing import List, Dict, Set
from pydantic_settings import BaseSettings
from pydantic import Field


# ══════════════════════════════════════════════════════════════
# CONSTANTS (Used by other modules)
# ══════════════════════════════════════════════════════════════

# Audio Constants
SAMPLE_RATE: int = 16000
MAX_DURATION: float = 600.0  # Extended to 10 minutes
MIN_DURATION: float = 0.3  # Lowered for better flexibility
MAX_FILE_SIZE_MB: int = 200  # Increased for longer files
CHUNK_DURATION: float = 30.0  # For processing long audio files

# Audio Enhancement Settings
NOISE_REDUCTION_ENABLED: bool = True
NOISE_REDUCTION_STRENGTH: float = 0.7
VAD_AGGRESSIVENESS: int = 2  # 0-3, higher = more aggressive
MIN_SPEECH_DURATION: float = 0.3  # Minimum speech segment duration

# Supported Audio Formats
SUPPORTED_FORMATS: Set[str] = {
    '.wav', '.mp3', '.m4a', '.ogg', 
    '.flac', '.webm', '.aac', '.wma',
    '.opus', '.amr', '.3gp'
}

# Locations (24 types)
LOCATIONS: List[str] = [
    "Airport Terminal",
    "Railway Station",
    "Bus Terminal",
    "Metro/Subway",
    "Hospital",
    "Shopping Mall",
    "Office Building",
    "School/University",
    "Restaurant/Cafe",
    "Street/Road",
    "Home/Residential",
    "Park/Outdoor",
    "Stadium/Arena",
    "Parking Area",
    "Construction Site",
    "Factory/Industrial",
    "Religious Place",
    "Government Office",
    "Bank",
    "Hotel/Lodge",
    "Cinema/Theater",
    "Gym/Sports Center",
    "Market/Bazaar",
    "Unknown"
]

# Situations (20 types)
SITUATIONS: List[str] = [
    "Normal/Quiet",
    "Busy/Crowded",
    "Emergency",
    "Boarding/Departure",
    "Waiting",
    "Traffic",
    "Meeting/Conference",
    "Announcement",
    "Celebration/Event",
    "Construction",
    "Weather Event",
    "Accident",
    "Medical Emergency",
    "Security Alert",
    "Rush Hour",
    "Flight Delay",
    "Train Delay",
    "Sports Event",
    "Concert/Music",
    "Unknown"
]

# Primary Emotions
EMOTIONS: List[str] = [
    "neutral",
    "happy",
    "sad",
    "angry",
    "fearful",
    "surprised",
    "disgusted"
]

# Micro Emotions
MICRO_EMOTIONS: List[str] = [
    "urgency",
    "excitement",
    "hesitation",
    "confidence",
    "stress",
    "calmness"
]

# Speech Intents
INTENTS: List[str] = [
    "announcement",
    "instruction",
    "information",
    "question",
    "request",
    "warning",
    "emergency",
    "greeting",
    "farewell",
    "complaint",
    "confirmation",
    "explanation",
    "conversation",
    "unknown"
]

# Extended Language Support (150+ languages)
SUPPORTED_LANGUAGES: Dict[str, str] = {
    # Major Languages
    "en": "English",
    "zh": "Chinese (Mandarin)",
    "zh-CN": "Chinese (Simplified)",
    "zh-TW": "Chinese (Traditional)",
    "hi": "Hindi",
    "es": "Spanish",
    "fr": "French",
    "ar": "Arabic",
    "bn": "Bengali",
    "pt": "Portuguese",
    "ru": "Russian",
    "ja": "Japanese",
    "pa": "Punjabi",
    "de": "German",
    "jv": "Javanese",
    "ko": "Korean",
    "te": "Telugu",
    "vi": "Vietnamese",
    "mr": "Marathi",
    "ta": "Tamil",
    "ur": "Urdu",
    "tr": "Turkish",
    "it": "Italian",
    "th": "Thai",
    "gu": "Gujarati",
    "pl": "Polish",
    "uk": "Ukrainian",
    "ml": "Malayalam",
    "kn": "Kannada",
    "or": "Odia",
    "my": "Burmese",
    
    # European Languages
    "nl": "Dutch",
    "sv": "Swedish",
    "da": "Danish",
    "no": "Norwegian",
    "fi": "Finnish",
    "el": "Greek",
    "cs": "Czech",
    "ro": "Romanian",
    "hu": "Hungarian",
    "sk": "Slovak",
    "bg": "Bulgarian",
    "hr": "Croatian",
    "sr": "Serbian",
    "sl": "Slovenian",
    "lt": "Lithuanian",
    "lv": "Latvian",
    "et": "Estonian",
    "sq": "Albanian",
    "mk": "Macedonian",
    "bs": "Bosnian",
    "is": "Icelandic",
    "ga": "Irish",
    "cy": "Welsh",
    "mt": "Maltese",
    
    # Asian Languages
    "id": "Indonesian",
    "ms": "Malay",
    "tl": "Tagalog",
    "lo": "Lao",
    "km": "Khmer",
    "si": "Sinhala",
    "ne": "Nepali",
    "am": "Amharic",
    "ti": "Tigrinya",
    "ps": "Pashto",
    "ku": "Kurdish",
    "sd": "Sindhi",
    "ug": "Uyghur",
    "bo": "Tibetan",
    "mn": "Mongolian",
    "ka": "Georgian",
    "hy": "Armenian",
    "az": "Azerbaijani",
    "uz": "Uzbek",
    "tk": "Turkmen",
    "kk": "Kazakh",
    "ky": "Kyrgyz",
    "tg": "Tajik",
    
    # Middle Eastern & African Languages
    "he": "Hebrew",
    "fa": "Persian",
    "sw": "Swahili",
    "ha": "Hausa",
    "yo": "Yoruba",
    "ig": "Igbo",
    "zu": "Zulu",
    "xh": "Xhosa",
    "af": "Afrikaans",
    "so": "Somali",
    "rw": "Kinyarwanda",
    "sn": "Shona",
    "ny": "Chichewa",
    "mg": "Malagasy",
    
    # Latin American Languages
    "qu": "Quechua",
    "gn": "Guarani",
    "ay": "Aymara",
    
    # Pacific Languages
    "mi": "Maori",
    "sm": "Samoan",
    "to": "Tongan",
    "fj": "Fijian",
    
    # Other Languages
    "eu": "Basque",
    "ca": "Catalan",
    "gl": "Galician",
    "oc": "Occitan",
    "be": "Belarusian",
    "yi": "Yiddish",
    "eo": "Esperanto",
    "la": "Latin",
    "sa": "Sanskrit",
}

# Language code mapping for translation services
LANGUAGE_CODE_MAPPING: Dict[str, str] = {
    "zh-CN": "zh",
    "zh-TW": "zh-TW",
    "pt-BR": "pt",
    "pt-PT": "pt",
    "es-ES": "es",
    "es-MX": "es",
}


# ══════════════════════════════════════════════════════════════
# SETTINGS CLASS
# ══════════════════════════════════════════════════════════════

class Settings(BaseSettings):
    """Application settings loaded from .env"""
    
    # Server
    HOST: str = Field(default="127.0.0.1")
    PORT: int = Field(default=8000)
    DEBUG: bool = Field(default=False)
    
    # Models
    WHISPER_MODEL: str = Field(default="openai/whisper-large-v3")
    WHISPER_DEVICE: str = Field(default="cpu")  # cpu or cuda
    WHISPER_COMPUTE_TYPE: str = Field(default="float32")  # float32, float16, int8
    
    # Speaker Diarization
    ENABLE_DIARIZATION: bool = Field(default=True)
    MIN_SPEAKERS: int = Field(default=1)
    MAX_SPEAKERS: int = Field(default=10)
    DIARIZATION_MODEL: str = Field(default="pyannote/speaker-diarization-3.1")
    
    # Translation
    PRIMARY_TRANSLATOR: str = Field(default="google")  # google, deepl, libre
    FALLBACK_TRANSLATOR: str = Field(default="deep-translator")
    AUTO_TRANSLATE: bool = Field(default=True)
    TARGET_LANGUAGE: str = Field(default="en")
    
    # Audio Enhancement
    ENABLE_NOISE_REDUCTION: bool = Field(default=True)
    ENABLE_VAD: bool = Field(default=True)
    NORMALIZE_AUDIO: bool = Field(default=True)
    
    # Audio Processing
    SAMPLE_RATE: int = Field(default=16000)
    MAX_DURATION: float = Field(default=600.0)
    MIN_DURATION: float = Field(default=0.3)
    MAX_FILE_SIZE_MB: int = Field(default=200)
    CHUNK_DURATION: float = Field(default=30.0)
    
    # Performance
    MAX_WORKERS: int = Field(default=4)
    ENABLE_CACHING: bool = Field(default=True)
    CACHE_TTL: int = Field(default=3600)  # seconds
    
    # FFmpeg
    FFMPEG_PATH: str = Field(default="")
    
    # Data
    DATA_DIR: str = Field(default="data")
    LEARNING_FILE: str = Field(default="learned_data.json")
    CACHE_DIR: str = Field(default="cache")
    MAX_HISTORY_SIZE: int = Field(default=1000)
    
    # API Keys (optional, for premium translation services)
    DEEPL_API_KEY: str = Field(default="")
    GOOGLE_TRANSLATE_API_KEY: str = Field(default="")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
        extra = "ignore"


# Create global settings instance
settings = Settings()


# ══════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════

def get_data_path(filename: str) -> str:
    """Get full path to data file"""
    data_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        settings.DATA_DIR
    )
    os.makedirs(data_dir, exist_ok=True)
    return os.path.join(data_dir, filename)


def get_cache_path(filename: str) -> str:
    """Get full path to cache file"""
    cache_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        settings.CACHE_DIR
    )
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, filename)


def get_learning_file_path() -> str:
    """Get path to learning data file"""
    return get_data_path(settings.LEARNING_FILE)


def normalize_language_code(lang_code: str) -> str:
    """Normalize language code for consistency"""
    lang_code = lang_code.lower().strip()
    return LANGUAGE_CODE_MAPPING.get(lang_code, lang_code.split('-')[0])


def is_supported_language(lang_code: str) -> bool:
    """Check if language is supported"""
    normalized = normalize_language_code(lang_code)
    return normalized in SUPPORTED_LANGUAGES