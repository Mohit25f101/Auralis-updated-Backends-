# ==============================
# 📄 api/routes/analyze.py
# ==============================
"""
Main Analysis Endpoint - Core Audio Processing
"""

import os
import time
import uuid
import tempfile
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, UploadFile, File, HTTPException, Depends, Query
from fastapi.responses import JSONResponse

from api.models.responses import (
    AnalysisResult,
    DetailedAnalysisResult,
    EmotionAnalysisResult,
    QuickAnalysisResult
)
from services.audio_loader import AudioLoader
from services.whisper_manager import WhisperManager
from services.yamnet_manager import YAMNetManager
from services.emotion_detector import EmotionDetector
from services.confidence_scorer import ConfidenceScorer
from services.context_synthesizer import ContextSynthesizer
from services.learning_system import LearningSystem
from config import settings
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from services.analyzer import Analyzer


router = APIRouter(prefix="/analyze", tags=["Analysis"])

# Global instances (initialized in lifespan)
_loader: Optional[AudioLoader] = None
_whisper: Optional[WhisperManager] = None
_yamnet: Optional[YAMNetManager] = None
_language_detector = None
_ambient_analyzer = None
_location_detector = None
_emotion: Optional[EmotionDetector] = None
_confidence: Optional[ConfidenceScorer] = None
_synthesizer: Optional[ContextSynthesizer] = None
_analyzer = None
_learning: Optional[LearningSystem] = None
_history: dict = {}


def init_services(
    loader: AudioLoader,
    whisper: WhisperManager,
    yamnet: YAMNetManager,
    language_detector,
    ambient_analyzer,
    location_detector,
    emotion: EmotionDetector,
    confidence: ConfidenceScorer,
    synthesizer: ContextSynthesizer,
    analyzer,
    learning: LearningSystem
):
    """Initialize all service instances"""
    global _loader, _whisper, _yamnet, _language_detector, _ambient_analyzer, _location_detector
    global _emotion, _confidence, _synthesizer, _analyzer, _learning
    
    _loader = loader
    _whisper = whisper
    _yamnet = yamnet
    _language_detector = language_detector
    _ambient_analyzer = ambient_analyzer
    _location_detector = location_detector
    _emotion = emotion
    _confidence = confidence
    _synthesizer = synthesizer
    _analyzer = analyzer
    _learning = learning


def get_history() -> dict:
    """Get analysis history"""
    return _history


@router.post("", response_model=AnalysisResult)
async def analyze_audio(
    file: UploadFile = File(..., description="Audio file to analyze"),
    detailed: bool = Query(False, description="Include detailed analysis"),
    include_emotions: bool = Query(True, description="Include emotion detection"),
    include_improvements: bool = Query(True, description="Include improvement suggestions"),
    language_hint: Optional[str] = Query(None, description="Language hint (e.g., 'hi', 'en', 'ta')")
):
    """
    🎙️ **Main Audio Analysis Endpoint**
    
    Analyzes audio file and returns:
    - Location detection (24+ locations)
    - Situation classification (20+ situations)
    - Micro-emotion detection (urgency, excitement, hesitation)
    - Speaker confidence scoring (1-10 scale)
    - Contextual improvement suggestions
    - Sound detection (521 audio classes)
    
    **Supported Formats**: WAV, MP3, M4A, OGG, FLAC, WEBM
    
    **Asian Context Optimization**: 
    - Indian railway announcements
    - Asian airport systems
    - Regional dialect understanding
    """
    start_time = time.time()
    request_id = uuid.uuid4().hex[:12]
    
    # Validate file
    if not file.filename:
        raise HTTPException(400, "No filename provided")
    
    allowed_extensions = {'.wav', '.mp3', '.m4a', '.ogg', '.flac', '.webm', '.aac'}
    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in allowed_extensions:
        raise HTTPException(400, f"Unsupported format: {ext}. Allowed: {allowed_extensions}")
    
    # Create temp files
    tmp_dir = tempfile.gettempdir()
    original_path = os.path.join(tmp_dir, f"auralis_{request_id}{ext}")
    wav_path = os.path.join(tmp_dir, f"auralis_{request_id}.wav")
    
    print("\n" + "=" * 70)
    print(f"📥 NEW ANALYSIS REQUEST")
    print(f"   📄 File: {file.filename}")
    print(f"   🔑 ID: {request_id}")
    print(f"   ⚙️ Detailed: {detailed} | Emotions: {include_emotions}")
    print("=" * 70)
    
    try:
        # Save uploaded file
        content = await file.read()
        file_size_kb = len(content) / 1024
        
        if file_size_kb > settings.MAX_FILE_SIZE_MB * 1024:
            raise HTTPException(413, f"File too large. Max: {settings.MAX_FILE_SIZE_MB}MB")
        
        with open(original_path, "wb") as f:
            f.write(content)
        
        print(f"   💾 Saved: {file_size_kb:.1f} KB")
        
        # Load and validate audio
        print("   🔊 Loading audio...")
        audio, duration = _loader.load(original_path)
        print(f"   ⏱️ Duration: {duration:.2f}s")
        
        if duration < settings.MIN_DURATION:
            raise HTTPException(400, f"Audio too short. Minimum: {settings.MIN_DURATION}s")
        
        if duration > settings.MAX_DURATION:
            audio = audio[:int(settings.SAMPLE_RATE * settings.MAX_DURATION)]
            duration = settings.MAX_DURATION
            print(f"   ⚠️ Trimmed to {settings.MAX_DURATION}s")
        
        # Save as WAV for processing
        _loader.save_wav(audio, wav_path)
        
        # Step 1: Transcription
        print("   🎤 Transcribing...")
        transcription = _whisper.transcribe(wav_path, language_hint=language_hint)
        
        if transcription.get("is_reliable"):
            preview = transcription['text'][:80] + "..." if len(transcription.get('text', '')) > 80 else transcription.get('text', '')
            print(f"   📝 ✓ \"{preview}\"")
        else:
            print(f"   📝 ⚠️ Speech unclear or unreliable")
        
        # Step 2: Sound Detection
        print("   🔊 Detecting sounds...")
        sound_analysis = _yamnet.analyze(audio)
        
        if sound_analysis.get("sounds"):
            print(f"   🎵 Sounds: {list(sound_analysis['sounds'].keys())[:5]}")
        if sound_analysis.get("location_hints"):
            print(f"   💡 Location hints: {[h[0] for h in sound_analysis['location_hints'][:3]]}")
        
        # Step 3: Core Analysis
        print("   🧠 Analyzing context...")
        core_analysis = _analyzer.analyze(transcription, sound_analysis)
        
        # Step 4: Emotion Detection (if enabled)
        emotion_analysis = None
        if include_emotions:
            print("   😊 Detecting emotions...")
            emotion_analysis = _emotion.analyze(
                audio=audio,
                text=transcription.get("text", ""),
                sounds=sound_analysis.get("sounds", {})
            )
            print(f"   🎭 Emotions: {emotion_analysis.get('primary_emotion', 'neutral')}")
        
        # Step 5: Confidence Scoring
        print("   📊 Scoring confidence...")
        confidence_score = _confidence.score(
            audio=audio,
            text=transcription.get("text", ""),
            transcription_confidence=transcription.get("confidence", 0),
            emotions=emotion_analysis
        )
        print(f"   📈 Speaker confidence: {confidence_score.get('overall_score', 5)}/10")
        
        # Step 6: Improvement Suggestions (if enabled)
        improvements = None
        if include_improvements:
            print("   💡 Generating improvements...")
            improvements = _synthesizer.synthesize(
                text=transcription.get("text", ""),
                emotions=emotion_analysis,
                confidence=confidence_score,
                location=core_analysis.get("location", "Unknown"),
                situation=core_analysis.get("situation", "Unknown")
            )
            print(f"   ✨ Suggestions: {len(improvements.get('suggestions', []))} generated")
        
        # Store in history
        _history[request_id] = {
            "transcription": transcription,
            "sounds": sound_analysis,
            "analysis": core_analysis,
            "emotions": emotion_analysis,
            "confidence": confidence_score,
            "improvements": improvements,
            "timestamp": datetime.now().isoformat()
        }
        
        # Limit history size
        if len(_history) > settings.MAX_HISTORY_SIZE:
            oldest_key = list(_history.keys())[0]
            del _history[oldest_key]
        
        # Calculate processing time
        processing_time_ms = (time.time() - start_time) * 1000
        
        # Build response
        response = AnalysisResult(
            # Core Analysis
            location=core_analysis["location"],
            location_confidence=core_analysis["location_confidence"],
            situation=core_analysis["situation"],
            situation_confidence=core_analysis["situation_confidence"],
            is_emergency=core_analysis["is_emergency"],
            emergency_probability=core_analysis["emergency_probability"],
            overall_confidence=core_analysis["overall_confidence"],
            
            # Transcription
            transcribed_text=transcription.get("text", ""),
            text_reliable=transcription.get("is_reliable", False),
            detected_language=transcription.get("detected_language", "en"),
            
            # Sounds
            detected_sounds=list(sound_analysis.get("sounds", {}).keys())[:15],
            sound_confidences={k: round(v, 3) for k, v in list(sound_analysis.get("sounds", {}).items())[:10]},
            
            # Emotions (if enabled)
            emotions=emotion_analysis if include_emotions else None,
            
            # Confidence Scoring
            speaker_confidence=confidence_score if confidence_score else None,
            
            # Improvements (if enabled)
            improvement_suggestions=improvements if include_improvements else None,
            
            # Evidence
            evidence=core_analysis.get("evidence", []),
            summary=core_analysis.get("summary", ""),
            
            # Metadata
            processing_time_ms=round(processing_time_ms, 1),
            request_id=request_id,
            timestamp=datetime.now().isoformat(),
            audio_duration=round(duration, 2),
            audio_sample_rate=settings.SAMPLE_RATE,
            
            # Asian Context
            asian_context_applied=True,
            regional_adaptations=_get_regional_context(core_analysis["location"])
        )
        
        # Print results
        print(f"\n   ✅ ANALYSIS COMPLETE:")
        print(f"      📍 Location: {response.location} ({response.location_confidence*100:.0f}%)")
        print(f"      🎯 Situation: {response.situation} ({response.situation_confidence*100:.0f}%)")
        print(f"      🚨 Emergency: {response.is_emergency} ({response.emergency_probability*100:.0f}%)")
        print(f"      ⏱️ Time: {response.processing_time_ms:.0f}ms")
        print("=" * 70 + "\n")
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"   💥 ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(500, f"Analysis failed: {str(e)}")
    finally:
        # Cleanup temp files
        for path in [original_path, wav_path]:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except:
                    pass


@router.post("/quick", response_model=QuickAnalysisResult)
async def quick_analyze(
    file: UploadFile = File(..., description="Audio file for quick analysis")
):
    """
    ⚡ **Quick Analysis Endpoint**
    
    Faster analysis with essential results only.
    Skips emotion detection and improvement suggestions.
    """
    start_time = time.time()
    request_id = uuid.uuid4().hex[:8]
    
    tmp_dir = tempfile.gettempdir()
    ext = os.path.splitext(file.filename or ".wav")[1].lower()
    original_path = os.path.join(tmp_dir, f"quick_{request_id}{ext}")
    wav_path = os.path.join(tmp_dir, f"quick_{request_id}.wav")
    
    try:
        content = await file.read()
        with open(original_path, "wb") as f:
            f.write(content)
        
        audio, duration = _loader.load(original_path)
        
        if duration > settings.MAX_DURATION:
            audio = audio[:int(settings.SAMPLE_RATE * settings.MAX_DURATION)]
        
        _loader.save_wav(audio, wav_path)
        
        transcription = _whisper.transcribe(wav_path)
        sound_analysis = _yamnet.analyze(audio)
        core_analysis = _analyzer.analyze(transcription, sound_analysis)
        
        processing_time_ms = (time.time() - start_time) * 1000
        
        return QuickAnalysisResult(
            location=core_analysis["location"],
            location_confidence=core_analysis["location_confidence"],
            situation=core_analysis["situation"],
            situation_confidence=core_analysis["situation_confidence"],
            is_emergency=core_analysis["is_emergency"],
            transcribed_text=transcription.get("text", "")[:200],
            detected_sounds=list(sound_analysis.get("sounds", {}).keys())[:5],
            processing_time_ms=round(processing_time_ms, 1),
            request_id=request_id
        )
        
    finally:
        for path in [original_path, wav_path]:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except:
                    pass


@router.post("/emotions", response_model=EmotionAnalysisResult)
async def analyze_emotions(
    file: UploadFile = File(..., description="Audio file for emotion analysis")
):
    """
    😊 **Emotion-Focused Analysis**
    
    Deep emotion analysis including:
    - Primary emotion detection
    - Micro-emotions (urgency, excitement, hesitation)
    - Emotional intensity (1-10)
    - Asian context emotional patterns
    """
    start_time = time.time()
    request_id = uuid.uuid4().hex[:8]
    
    tmp_dir = tempfile.gettempdir()
    ext = os.path.splitext(file.filename or ".wav")[1].lower()
    original_path = os.path.join(tmp_dir, f"emo_{request_id}{ext}")
    wav_path = os.path.join(tmp_dir, f"emo_{request_id}.wav")
    
    try:
        content = await file.read()
        with open(original_path, "wb") as f:
            f.write(content)
        
        audio, duration = _loader.load(original_path)
        _loader.save_wav(audio, wav_path)
        
        transcription = _whisper.transcribe(wav_path)
        sound_analysis = _yamnet.analyze(audio)
        
        emotion_analysis = _emotion.analyze(
            audio=audio,
            text=transcription.get("text", ""),
            sounds=sound_analysis.get("sounds", {}),
            detailed=True
        )
        
        confidence_score = _confidence.score(
            audio=audio,
            text=transcription.get("text", ""),
            transcription_confidence=transcription.get("confidence", 0),
            emotions=emotion_analysis
        )
        
        processing_time_ms = (time.time() - start_time) * 1000
        
        return EmotionAnalysisResult(
            primary_emotion=emotion_analysis.get("primary_emotion", "neutral"),
            emotion_confidence=emotion_analysis.get("confidence", 0.5),
            micro_emotions=emotion_analysis.get("micro_emotions", {}),
            emotional_intensity=emotion_analysis.get("intensity", 5),
            speaker_confidence_score=confidence_score.get("overall_score", 5),
            confidence_breakdown=confidence_score.get("breakdown", {}),
            emotional_trajectory=emotion_analysis.get("trajectory", []),
            asian_context_patterns=emotion_analysis.get("asian_patterns", {}),
            transcribed_text=transcription.get("text", ""),
            processing_time_ms=round(processing_time_ms, 1),
            request_id=request_id
        )
        
    finally:
        for path in [original_path, wav_path]:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except:
                    pass


def _get_regional_context(location: str) -> dict:
    """Get regional adaptations based on location"""
    regional_contexts = {
        "Railway Station": {
            "region": "South Asia",
            "adaptations": ["Indian Railways terminology", "Platform numbering system", "Coach/Bogey terminology"],
            "common_languages": ["Hindi", "English", "Regional languages"]
        },
        "Airport Terminal": {
            "region": "International/Asia",
            "adaptations": ["Multi-language announcements", "Asian carrier recognition", "Regional airport codes"],
            "common_languages": ["English", "Hindi", "Mandarin", "Japanese"]
        },
        "Metro/Subway": {
            "region": "Urban Asia",
            "adaptations": ["Delhi Metro style", "Token/Card systems", "Line color coding"],
            "common_languages": ["Hindi", "English", "Local language"]
        },
        "Religious Place": {
            "region": "South Asia",
            "adaptations": ["Temple/Mandir terminology", "Prayer times", "Festival awareness"],
            "common_languages": ["Sanskrit", "Hindi", "Regional languages"]
        }
    }
    
    return regional_contexts.get(location, {
        "region": "General",
        "adaptations": ["Standard analysis"],
        "common_languages": ["English"]
    })
